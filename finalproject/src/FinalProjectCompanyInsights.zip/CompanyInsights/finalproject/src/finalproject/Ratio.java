/**
 * 
 */

/**
 * 
 */
public interface Ratio {

}
