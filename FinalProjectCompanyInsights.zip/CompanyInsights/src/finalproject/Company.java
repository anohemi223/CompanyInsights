/**
 * 
 */
package finalproject;

/**
 * 
 */
public class Company {

}
