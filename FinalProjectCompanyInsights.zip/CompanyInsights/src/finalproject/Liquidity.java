/**
 * 
 */
package finalproject;

/**
 * 
 */
public class Liquidity extends Metrics {

	/**
	 * 
	 */
	public Liquidity() {
		// TODO Auto-generated constructor stub
	}

}
