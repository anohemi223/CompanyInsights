/**
 * 
 */
package finalproject;

/**
 * 
 */
public class Efficiency extends Metrics {

	/**
	 * 
	 */
	public Efficiency() {
		// TODO Auto-generated constructor stub
	}

}
