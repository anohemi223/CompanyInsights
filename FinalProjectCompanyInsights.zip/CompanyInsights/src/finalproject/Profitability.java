/**
 * 
 */
package finalproject;

/**
 * 
 */
public class Profitability extends Metrics {

	/**
	 * 
	 */
	public Profitability() {
		// TODO Auto-generated constructor stub
	}

}
